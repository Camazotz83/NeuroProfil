# NeuroProfil 3.0 — Clinical Matrix

A major functional and design revision of NeuroProfil.

## Added
- development timeline + trait/state distinction
- multi-setting relevance and evidence quality
- function and impairment separated from unusual traits
- focused formulation for selected key traits: onset, context, function, distress, compensation, evidence, alternative explanation, counterevidence, concrete example
- executive function profile
- sensory direction profile (hyper / hypo-seeking / mixed)
- interoception profile
- emotion/stress regulation profile
- social-communication mechanism layer
- masking and compensation strategies
- strengths/resources profile
- psychodynamic tension axes as explicitly falsifiable hypotheses only
- internal motivation vs external adaptation
- longitudinal local snapshots
- short and full PDF report
- local export/import
- PayPal support entry
- imprint / legal section

## Important imprint note
The imprint UI is present, but the identifying fields in `app/src/main/assets/config.js` are placeholders.
Before public distribution, replace them with the provider name, a serviceable postal address and email address appropriate for your jurisdiction.
The PayPal URL is already configured.

## Privacy
No account, analytics, ads, backend or data upload. Android backup is disabled. External URLs open outside the app.
