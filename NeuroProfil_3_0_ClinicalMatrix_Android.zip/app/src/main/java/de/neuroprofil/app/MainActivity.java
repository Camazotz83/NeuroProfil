package de.neuroprofil.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9,10,11));
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(false); s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false); s.setTextZoom(100);
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeBridge(this), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }
    private void openPrintDialog() {
        PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
        PrintDocumentAdapter adapter=webView.createPrintDocumentAdapter("NeuroProfil_3_Bericht");
        PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_COLOR).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
        pm.print("NeuroProfil 3 — strukturierter Bericht",adapter,attrs);
    }
    private void shareTextNative(String text){Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(send,"Teilen"));}
    private void openExternal(String url){try{Uri u=Uri.parse(url);if(!"https".equalsIgnoreCase(u.getScheme()))throw new IllegalArgumentException();startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){Toast.makeText(this,"Link konnte nicht geöffnet werden.",Toast.LENGTH_LONG).show();}}
    public final class NativeBridge {
        private final Context context; NativeBridge(Context c){context=c;}
        @JavascriptInterface public void printPage(){runOnUiThread(()->{try{openPrintDialog();}catch(Exception e){Toast.makeText(context,"PDF-Dialog konnte nicht geöffnet werden.",Toast.LENGTH_LONG).show();}});}
        @JavascriptInterface public void shareText(String text){runOnUiThread(()->shareTextNative(text));}
        @JavascriptInterface public void openUrl(String url){runOnUiThread(()->openExternal(url));}
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(webView!=null){webView.destroy();webView=null;}super.onDestroy();}
}
