window.NP_CONFIG = {
  version: "3.0.0",
  edition: "Clinical Matrix",
  paypal: "https://www.paypal.com/paypalme/wahmhoff83",
  imprint: {
    name: "[Name des Anbieters ergänzen]",
    address: "[ladungsfähige Anschrift ergänzen]",
    email: "[E-Mail-Adresse ergänzen]"
  }
};
