# NeuroProfil 5.0 — Preis- und Produktvorschlag

Die App zeigt im UI ausschließlich die lokalisierten Google-Play-Preise. Diese Datei ist die Startempfehlung für die Play Console.

## 1) Bericht Plus — Einmalkauf
Produkt-ID: `neuroprofil_report_plus`
Empfohlener Startpreis DE: **4,99 € einmalig**
Enthält: Vollbericht + teilbare Kurzkarte.

## 2) Pro — Jahresabo
Produkt-ID: `neuroprofil_pro_yearly`
Empfohlener Startpreis DE: **19,99 € / Jahr**
Enthält: Bericht Plus + unbegrenzte Vertiefungen + unbegrenzte Verlaufssnapshots.

## 3) Pro — dauerhaft
Produkt-ID: `neuroprofil_pro_lifetime`
Empfohlener Startpreis DE: **44,99 € einmalig**
Enthält: dauerhafte Pro-Freischaltung.

## Was immer kostenlos bleibt
- alle 136 Beobachtungen
- kompletter Entwicklungs-/Kontextteil
- 5-P-Fallformulierung
- Basis-Auswertung und Gegenprüfung
- eine Vertiefung
- ein Snapshot
- Kurzbericht
- Datenexport, Import und Löschen

## Warum dieses Modell
Kein Bezahlen für eine „bessere Diagnose“. Der günstige Einmalkauf fängt Gelegenheitsnutzer ab; Pro richtet sich an Menschen, die Verlauf und Dokumentation fortlaufend nutzen. Keine Countdown-Timer, Fake-Rabatte oder Angst-CTA.
