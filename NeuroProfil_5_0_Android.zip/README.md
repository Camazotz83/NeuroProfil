# NeuroProfil 5.0 — Selbstanamnese & Verlauf

Eine privacy-first Android-App für Erwachsene, die Beobachtungen zu Aufmerksamkeit, Sensorik, sozialer Verarbeitung, Regulation und Alltag strukturiert für Selbstklärung und professionelle Gespräche ordnen möchten.

## Produktprinzip

NeuroProfil verkauft keine Diagnose. Die klinische Kern-Selbstanamnese bleibt frei. Monetarisiert werden Dokumentationskomfort, Vollbericht und fortlaufender Verlauf.

## Version 5.0

- neue Startseite mit verständlichem Vier-Schritte-Weg
- fünf klare Hauptbereiche: Start / Beobachten / Kontext / Formulieren / Bericht
- 136 Beobachtungen als Beobachtungsarchiv statt Pseudo-Symptomtest
- weichere, nicht-diagnostische Einordnungstexte
- Entwicklungs-, Kontext-, Funktions- und Evidenzebene
- explizite Alternativerklärungen und Gegenbelege
- 5-P-Fallformulierung
- Beziehungsschleifen, Spannungsthemen und psychische Funktionen als psychodynamische Reflexion
- OPD-3-inspirierte Denkachsen ohne OPD-Rating
- Ressourcen und hilfreiche Anpassungen gleichberechtigt
- kurze teilbare Karte ohne Diagnoseclaim und mit Share-Consent
- vollständiges Impressum-/Datenschutz-/Methodik-Menü
- lokale Daten; kein Konto, keine Werbung, keine Analytics, keine Cloud
- Google Play Billing 9.1.0
- targetSdk 36 / Android 16

## Monetarisierung

- Free: komplette inhaltliche Kernfunktion + Kurzbericht + ein vertieftes Merkmal + ein Verlaufspunkt + Datenexport/import
- Bericht Plus: Vollbericht + teilbare Kurzkarte
- Pro Jahr: Plus + unbegrenzte Vertiefung und Verlauf
- Pro dauerhaft: dauerhafte Pro-Freischaltung

Produkt-IDs:
- neuroprofil_report_plus
- neuroprofil_pro_yearly
- neuroprofil_pro_lifetime

## Rechtliches

Der Preview-Build zeigt Platzhalter, solange keine echten Anbieterangaben hinterlegt sind. Der Google-Play-Build verlangt die Secrets NEURO_LEGAL_NAME, NEURO_LEGAL_ADDRESS und NEURO_LEGAL_EMAIL und bricht ohne sie ab.
