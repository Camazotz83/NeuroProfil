window.NP_CONFIG = {
  version: "5.0.0",
  audience: "Erwachsene ab 18 Jahren",
  paypal: "https://www.paypal.com/paypalme/wahmhoff83",
  privacyUrl: "",
  termsUrl: "",
  playProducts: {
    report: "neuroprofil_report_plus",
    yearly: "neuroprofil_pro_yearly",
    lifetime: "neuroprofil_pro_lifetime"
  },
  imprint: {
    name: "[Name des Anbieters ergänzen]",
    address: "[ladungsfähige Anschrift ergänzen]",
    email: "[Support-/Kontakt-E-Mail ergänzen]"
  }
};
