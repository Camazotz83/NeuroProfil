# Monetarisierung – Startkonfiguration

Google Play Produkte:
- Abo: `neuroprofil_pro_yearly`
- Einmalkauf: `neuroprofil_pro_lifetime`

Preis-Hypothese zum Start (nicht als „optimal“ validiert):
- Pro Jahr: 29,99 €
- Pro dauerhaft: 69,99 €

Frei: 136 Merkmale, kompletter Kontext, Basis-Auswertung, 1 Schlüsselmerkmal, 1 Snapshot, Kurzbericht.
Pro: unbegrenzte Vertiefung, Mehrzeitpunkt-Verlauf, Vollbericht, Datenexport/-import.

Keine bessere „Diagnose“ verkaufen. Keine Sicherheitshinweise paywallen. Keine Countdown-Timer, Fake-Rabatte oder Angstformulierungen.
