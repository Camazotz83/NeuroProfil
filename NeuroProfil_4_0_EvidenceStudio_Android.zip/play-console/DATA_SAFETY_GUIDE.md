# Google Play Data Safety – technische Ausgangslage

- Gesundheits-/Selbstanamnese-Inhalte lokal im App-Speicher.
- Kein eigenes Konto, keine Cloud, keine Werbung, keine Analytics.
- Keine Standort-, Kamera-, Mikrofon-, Kontakt- oder Health-Connect-Berechtigungen.
- Android-Cloud-Backup der Inhaltsdaten deaktiviert.
- Optionale Pro-Käufe über Google Play Billing.

Vor Einreichung die Data-Safety-Maske anhand des finalen Builds prüfen. Bei späterem Einbau von Analytics, Crash-Reporting, Login oder Cloud-Sync zwingend aktualisieren.
