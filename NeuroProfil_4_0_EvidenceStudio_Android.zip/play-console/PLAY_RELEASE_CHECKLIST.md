# NeuroProfil 4.0 – Play-Release-Checkliste

1. GitHub Secrets anlegen: `NEURO_LEGAL_NAME`, `NEURO_LEGAL_ADDRESS`, `NEURO_LEGAL_EMAIL`.
2. Private Signing-Secrets aus dem separat gelieferten privaten ZIP anlegen.
3. Workflow `Publish NeuroProfil legal pages` ausführen und öffentliche URLs prüfen.
4. Health Apps Declaration in Play Console ausfüllen.
5. Data Safety anhand des finalen Builds ausfüllen.
6. Google-Play-Produkte `neuroprofil_pro_yearly` und `neuroprofil_pro_lifetime` anlegen.
7. Google Play App Signing aktivieren.
8. Workflow `NeuroProfil 4.0 — Google Play AAB` ausführen.
9. AAB zunächst in den internen Test hochladen.
10. Kauf, Wiederherstellung, Offline-Start, PDF, Datenlöschung, große Schrift und Rotation testen.
11. Falls das private Entwicklerkonto nach dem 13.11.2023 erstellt wurde: geschlossener Test mit mindestens 12 Testern über 14 aufeinanderfolgende Tage, bevor Produktionszugriff beantragt werden kann.
12. Erst nach echtem Testerfeedback Produktion beantragen.
