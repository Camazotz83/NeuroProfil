# NeuroProfil – strukturierte Selbstanamnese

## Kurzbeschreibung
Strukturierte Selbstbeobachtung zu ADHS-/Autismus-nahen Mustern – privat, differenziert und ohne Scheindiagnosen.

## Vollständige Beschreibung
NeuroProfil hilft Erwachsenen, wiederkehrende Beobachtungen strukturiert festzuhalten und für ein Gespräch mit qualifizierten Fachpersonen aufzubereiten.

Enthalten sind 136 alltagsnahe Beobachtungen, Entwicklungsbeginn, mehrere Lebensbereiche, Funktionsbeeinträchtigung, Kompensation, Evidenzqualität, mögliche Alternativerklärungen und Gegenbelege sowie sensorische, exekutive, interozeptive, emotionale und psychologische Reflexionsebenen.

NeuroProfil ist kein Medizinprodukt, kein validierter Screening- oder Diagnosetest und berechnet keine Diagnosewahrscheinlichkeit. Die App diagnostiziert, behandelt, heilt oder verhindert keine Erkrankung. Bei medizinischem oder psychischem Beratungsbedarf wende dich an eine qualifizierte Fachperson.

Gesundheitsbezogene Eingaben bleiben lokal auf dem Gerät. Keine Anmeldung, keine Werbung, kein Tracking, keine Analytics und keine Cloud-Synchronisation.

NeuroProfil Pro erweitert Dokumentation und Workflow um unbegrenzte Vertiefung, Verlauf, Datensicherung und Vollbericht. Ein Kauf verändert niemals die klinische Interpretation.
