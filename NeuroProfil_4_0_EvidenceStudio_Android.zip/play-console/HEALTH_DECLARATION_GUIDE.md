# Google Play Health Apps Declaration – NeuroProfil 4.0

Voraussichtlich passend: **Medical → Mental and Behavioral Health**.

Nicht als Medizinprodukt, Clinical Decision Support oder Healthcare Service deklarieren, solange die App unverändert bleibt.

Begründung: Selbstbeobachtungs-/Gesprächsvorbereitungswerkzeug zu psychischer Gesundheit und Neurodivergenz; keine Diagnose, Behandlung oder klinische Entscheidung.

Store und App sichtbar: „NeuroProfil ist kein Medizinprodukt und dient nicht der Diagnose, Behandlung, Heilung oder Prävention von Krankheiten. Für medizinischen Rat, Diagnose oder Behandlung ist eine qualifizierte Fachperson aufzusuchen.“
