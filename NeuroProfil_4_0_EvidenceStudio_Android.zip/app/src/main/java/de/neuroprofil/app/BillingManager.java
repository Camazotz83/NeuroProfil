package de.neuroprofil.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.WebView;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetailsResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryProductDetailsResult;
import com.android.billingclient.api.QueryPurchasesParams;

import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class BillingManager implements PurchasesUpdatedListener {
    public static final String YEARLY = "neuroprofil_pro_yearly";
    public static final String LIFETIME = "neuroprofil_pro_lifetime";
    private final Activity activity;
    private final WebView webView;
    private final SharedPreferences prefs;
    private final BillingClient billingClient;
    private final Map<String, ProductDetails> products = new HashMap<>();
    private volatile boolean connected = false;

    public BillingManager(Activity activity, WebView webView) {
        this.activity = activity; this.webView = webView;
        prefs = activity.getSharedPreferences("neuroprofil_entitlement", Context.MODE_PRIVATE);
        billingClient = BillingClient.newBuilder(activity)
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .build();
    }

    public void start() {
        if (connected || billingClient.isReady()) { connected = true; refreshAll(); return; }
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                connected = result.getResponseCode() == BillingClient.BillingResponseCode.OK;
                if (connected) refreshAll(); else notifyJs("billing_unavailable", result.getDebugMessage());
            }
            @Override public void onBillingServiceDisconnected() { connected = false; }
        });
    }

    public String stateJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("pro", prefs.getBoolean("lifetime", false) || prefs.getBoolean("yearly", false));
            o.put("lifetime", prefs.getBoolean("lifetime", false));
            o.put("yearly", prefs.getBoolean("yearly", false));
            o.put("connected", connected);
            o.put("yearlyPrice", prefs.getString("yearlyPrice", ""));
            o.put("lifetimePrice", prefs.getString("lifetimePrice", ""));
            return o.toString();
        } catch (Exception e) { return "{\"pro\":false}"; }
    }

    private void refreshAll() {
        queryProduct(BillingClient.ProductType.SUBS, YEARLY);
        queryProduct(BillingClient.ProductType.INAPP, LIFETIME);
        queryOwned(BillingClient.ProductType.SUBS);
        queryOwned(BillingClient.ProductType.INAPP);
    }

    private void queryProduct(String type, String id) {
        List<QueryProductDetailsParams.Product> items = new ArrayList<>();
        items.add(QueryProductDetailsParams.Product.newBuilder().setProductId(id).setProductType(type).build());
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(items).build();
        billingClient.queryProductDetailsAsync(params, new ProductDetailsResponseListener() {
            @Override public void onProductDetailsResponse(BillingResult result, QueryProductDetailsResult data) {
                if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
                for (ProductDetails pd : data.getProductDetailsList()) {
                    products.put(pd.getProductId(), pd);
                    String price = formattedPrice(pd);
                    if (YEARLY.equals(pd.getProductId())) prefs.edit().putString("yearlyPrice", price).apply();
                    if (LIFETIME.equals(pd.getProductId())) prefs.edit().putString("lifetimePrice", price).apply();
                }
                notifyState();
            }
        });
    }

    private String formattedPrice(ProductDetails pd) {
        try {
            if (BillingClient.ProductType.INAPP.equals(pd.getProductType())) {
                List<ProductDetails.OneTimePurchaseOfferDetails> offers = pd.getOneTimePurchaseOfferDetailsList();
                if (offers != null && !offers.isEmpty()) return offers.get(0).getFormattedPrice();
                ProductDetails.OneTimePurchaseOfferDetails legacy = pd.getOneTimePurchaseOfferDetails();
                return legacy == null ? "" : legacy.getFormattedPrice();
            }
            List<ProductDetails.SubscriptionOfferDetails> offers = pd.getSubscriptionOfferDetails();
            if (offers != null && !offers.isEmpty()) {
                List<ProductDetails.PricingPhase> phases = offers.get(0).getPricingPhases().getPricingPhaseList();
                if (!phases.isEmpty()) return phases.get(phases.size()-1).getFormattedPrice();
            }
        } catch (Exception ignored) {}
        return "";
    }

    private void queryOwned(String type) {
        billingClient.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(type).build(), new PurchasesResponseListener() {
            @Override public void onQueryPurchasesResponse(BillingResult result, List<Purchase> purchases) {
                if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
                boolean owned = false;
                for (Purchase p : purchases) {
                    if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                        processPurchase(p);
                        if (BillingClient.ProductType.SUBS.equals(type) && p.getProducts().contains(YEARLY)) owned = true;
                        if (BillingClient.ProductType.INAPP.equals(type) && p.getProducts().contains(LIFETIME)) owned = true;
                    }
                }
                if (BillingClient.ProductType.SUBS.equals(type)) prefs.edit().putBoolean("yearly", owned).apply();
                if (BillingClient.ProductType.INAPP.equals(type)) prefs.edit().putBoolean("lifetime", owned).apply();
                notifyState();
            }
        });
    }

    public void purchase(String productId) {
        activity.runOnUiThread(() -> {
            if (!billingClient.isReady()) { start(); notifyJs("billing_wait", "Google Play wird verbunden. Bitte gleich noch einmal versuchen."); return; }
            ProductDetails pd = products.get(productId);
            if (pd == null) { refreshAll(); notifyJs("product_wait", "Produktdaten werden geladen. Bitte gleich noch einmal versuchen."); return; }
            try {
                BillingFlowParams.ProductDetailsParams.Builder pb = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd);
                if (BillingClient.ProductType.SUBS.equals(pd.getProductType())) {
                    List<ProductDetails.SubscriptionOfferDetails> offers = pd.getSubscriptionOfferDetails();
                    if (offers == null || offers.isEmpty()) { notifyJs("no_offer", "Für dieses Abo ist derzeit kein Google-Play-Angebot verfügbar."); return; }
                    pb.setOfferToken(offers.get(0).getOfferToken());
                } else {
                    List<ProductDetails.OneTimePurchaseOfferDetails> offers = pd.getOneTimePurchaseOfferDetailsList();
                    if (offers != null && !offers.isEmpty()) pb.setOfferToken(offers.get(0).getOfferToken());
                }
                List<BillingFlowParams.ProductDetailsParams> list = new ArrayList<>(); list.add(pb.build());
                BillingResult br = billingClient.launchBillingFlow(activity, BillingFlowParams.newBuilder().setProductDetailsParamsList(list).build());
                if (br.getResponseCode() != BillingClient.BillingResponseCode.OK) notifyJs("purchase_error", br.getDebugMessage());
            } catch (Exception e) { notifyJs("purchase_error", "Kaufdialog konnte nicht geöffnet werden."); }
        });
    }

    public void restore() {
        if (!billingClient.isReady()) start();
        else { queryOwned(BillingClient.ProductType.SUBS); queryOwned(BillingClient.ProductType.INAPP); notifyJs("restore", "Käufe werden geprüft."); }
    }

    @Override public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase p : purchases) processPurchase(p); notifyState();
        } else if (result.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) notifyJs("purchase_error", result.getDebugMessage());
    }

    private void processPurchase(Purchase p) {
        if (p.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;
        if (p.getProducts().contains(LIFETIME)) prefs.edit().putBoolean("lifetime", true).apply();
        if (p.getProducts().contains(YEARLY)) prefs.edit().putBoolean("yearly", true).apply();
        if (!p.isAcknowledged()) billingClient.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.getPurchaseToken()).build(), result -> notifyState());
    }

    private void notifyState() {
        String json = stateJson();
        activity.runOnUiThread(() -> webView.evaluateJavascript("window.NeuroBilling&&window.NeuroBilling.update(" + JSONObject.quote(json) + ");", null));
    }
    private void notifyJs(String event, String message) {
        try {
            JSONObject o = new JSONObject(); o.put("event",event); o.put("message",message==null?"":message); String json=o.toString();
            activity.runOnUiThread(() -> webView.evaluateJavascript("window.NeuroBilling&&window.NeuroBilling.notice(" + JSONObject.quote(json) + ");", null));
        } catch (Exception ignored) {}
    }
    public void close() { try { billingClient.endConnection(); } catch (Exception ignored) {} }
}
