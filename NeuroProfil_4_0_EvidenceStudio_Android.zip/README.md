# NeuroProfil 4.0 — Evidence Studio

Privacy-first Android self-anamnesis app for adults.

- targetSdk / compileSdk 36
- Google Play Billing 9.1.0
- no ads, analytics, login or cloud
- local health-data processing
- Android backup disabled for app content
- falsification-oriented analysis
- free clinical core; Pro only for workflow/documentation
- AAB-ready signing workflow
- Play Console launch kit included

Product IDs: `neuroprofil_pro_yearly`, `neuroprofil_pro_lifetime`.

Before public release replace all imprint/privacy placeholders with the real provider information.
