package de.neuroprofil.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private BillingManager billing;
    private LicenseManager licenses;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this); webView.setBackgroundColor(Color.rgb(9,10,11)); setContentView(webView);
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(false); s.setAllowFileAccess(true); s.setAllowContentAccess(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false); float fontScale=getResources().getConfiguration().fontScale; int zoom=Math.round(100f*Math.max(1f,Math.min(fontScale,2f))); s.setTextZoom(zoom); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        billing=new BillingManager(this,webView); licenses=new LicenseManager(this); webView.addJavascriptInterface(new NativeBridge(this),"Android"); webView.loadUrl("file:///android_asset/index.html"); billing.start();
    }
    @Override protected void onResume(){super.onResume();if(billing!=null)billing.start();}
    private void openPrintDialog(){PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);PrintDocumentAdapter a=webView.createPrintDocumentAdapter("NeuroProfil_5_1_Bericht");PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_COLOR).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();pm.print("NeuroProfil 5.1 — strukturierter Bericht",a,attrs);}
    private void shareTextNative(String text){Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(send,"Teilen"));}
    private void openExternal(String url){try{Uri u=Uri.parse(url);if(!"https".equalsIgnoreCase(u.getScheme()))throw new IllegalArgumentException();startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){Toast.makeText(this,"Link konnte nicht geöffnet werden.",Toast.LENGTH_LONG).show();}}
    public final class NativeBridge {
        private final Context context; NativeBridge(Context c){context=c;}
        @JavascriptInterface public void printPage(){runOnUiThread(()->{try{openPrintDialog();}catch(Exception e){Toast.makeText(context,"PDF-Dialog konnte nicht geöffnet werden.",Toast.LENGTH_LONG).show();}});}
        @JavascriptInterface public void shareText(String text){runOnUiThread(()->shareTextNative(text));}
        @JavascriptInterface public void openUrl(String url){runOnUiThread(()->openExternal(url));}
        @JavascriptInterface public String billingState(){return billing==null?"{\"pro\":false}":billing.stateJson();}
        @JavascriptInterface public void buy(String productId){if(billing!=null)billing.purchase(productId);}
        @JavascriptInterface public void restorePurchases(){if(billing!=null)billing.restore();}
        @JavascriptInterface public boolean isPlayDistribution(){return BuildConfig.PLAY_DISTRIBUTION;}
        @JavascriptInterface public String licenseState(){return licenses==null?"{\"active\":false}":licenses.stateJson();}
        @JavascriptInterface public String activateLicense(String username,String key){return licenses==null?"{\"ok\":false}":licenses.activate(username,key);}
        @JavascriptInterface public void logoutLicense(){if(licenses!=null)licenses.logout();}
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(billing!=null)billing.close();if(webView!=null){webView.destroy();webView=null;}super.onDestroy();}
}
