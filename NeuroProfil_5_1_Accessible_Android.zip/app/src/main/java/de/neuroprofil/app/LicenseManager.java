package de.neuroprofil.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Locale;

public final class LicenseManager {
    private static final String PREFS = "neuroprofil_license_v1";
    private static final String PREFIX = "NP51";
    private static final String PUBLIC_KEY_B64 = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEASXV7UtJ6lsS6zHiOFnucYd+g9HziijrHjT3EFRMbTjJ9ZdqreHwzCcG9YJzzB/czVV8qYqbVVIhXvGmicS25Q==";
    private static final String OWNER_USER = "sasa";
    private static final String OWNER_KEY_SHA256 = "7ae5114212ff9e40c0f02508e3fc3e59d56b754cf428aa43d3bcf8a24a0ccd5f";

    private final SharedPreferences prefs;

    public LicenseManager(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String stateJson() {
        try {
            JSONObject o = new JSONObject();
            String tier = prefs.getString("tier", "");
            String user = prefs.getString("user", "");
            String source = prefs.getString("source", "");
            boolean active = !tier.isEmpty();
            boolean pro = "pro".equals(tier);
            boolean report = pro || "report".equals(tier);
            o.put("active", active);
            o.put("tier", tier);
            o.put("user", user);
            o.put("source", source);
            o.put("pro", pro);
            o.put("report", report);
            return o.toString();
        } catch (Exception e) {
            return "{\"active\":false,\"pro\":false,\"report\":false}";
        }
    }

    public String activate(String username, String key) {
        String user = username == null ? "" : username.trim();
        String token = key == null ? "" : key.trim();

        // Owner shortcut is intentionally limited to preview/direct builds.
        // Shipping a universal master password in a public Play binary would be insecure.
        if (!BuildConfig.PLAY_DISTRIBUTION
                && OWNER_USER.equals(user.toLowerCase(Locale.ROOT))
                && constantTimeEquals(sha256Hex(token), OWNER_KEY_SHA256)) {
            save(user, "pro", "owner-preview");
            return result(true, "pro", "Eigener Preview-Zugang aktiviert.");
        }

        if (!token.startsWith(PREFIX + ".")) {
            return result(false, "", "Der Zugangsschlüssel hat kein gültiges NeuroProfil-Format.");
        }

        try {
            String[] parts = token.split("\\.");
            if (parts.length != 3 || !PREFIX.equals(parts[0])) {
                return result(false, "", "Der Zugangsschlüssel ist unvollständig.");
            }

            String payloadB64 = parts[1];
            byte[] sigBytes = urlDecode(parts[2]);

            PublicKey publicKey = KeyFactory.getInstance("EC").generatePublic(
                    new X509EncodedKeySpec(Base64.decode(PUBLIC_KEY_B64, Base64.DEFAULT)));

            Signature verifier = Signature.getInstance("SHA256withECDSA");
            verifier.initVerify(publicKey);
            verifier.update(payloadB64.getBytes(StandardCharsets.US_ASCII));

            if (!verifier.verify(sigBytes)) {
                return result(false, "", "Die Signatur des Zugangsschlüssels ist ungültig.");
            }

            JSONObject payload = new JSONObject(new String(urlDecode(payloadB64), StandardCharsets.UTF_8));
            if (payload.optInt("v", 0) != 1) {
                return result(false, "", "Dieser Schlüssel gehört zu einer nicht unterstützten Lizenzversion.");
            }

            String licensedUser = payload.optString("user", "").trim();
            String tier = payload.optString("tier", "").trim().toLowerCase(Locale.ROOT);
            long exp = payload.optLong("exp", 0L);

            if (!licensedUser.equalsIgnoreCase(user)) {
                return result(false, "", "Nutzername und Zugangsschlüssel gehören nicht zusammen.");
            }
            if (!("free".equals(tier) || "report".equals(tier) || "pro".equals(tier))) {
                return result(false, "", "Der Lizenzumfang ist unbekannt.");
            }
            long now = System.currentTimeMillis() / 1000L;
            if (exp > 0 && now > exp) {
                return result(false, "", "Dieser Zugangsschlüssel ist abgelaufen.");
            }

            save(licensedUser, tier, "signed-key");
            String label = "pro".equals(tier) ? "Pro" : ("report".equals(tier) ? "Bericht Plus" : "Frei");
            return result(true, tier, label + " wurde für " + licensedUser + " aktiviert.");
        } catch (Exception e) {
            return result(false, "", "Der Zugangsschlüssel konnte nicht geprüft werden.");
        }
    }

    public void logout() {
        prefs.edit().clear().apply();
    }

    private void save(String user, String tier, String source) {
        prefs.edit().putString("user", user).putString("tier", tier).putString("source", source).apply();
    }

    private static String result(boolean ok, String tier, String message) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", ok);
            o.put("tier", tier);
            o.put("message", message);
            return o.toString();
        } catch (Exception e) {
            return "{\"ok\":false,\"message\":\"Unbekannter Fehler\"}";
        }
    }

    private static byte[] urlDecode(String value) {
        String padded = value;
        int mod = value.length() % 4;
        if (mod == 2) padded += "==";
        else if (mod == 3) padded += "=";
        return Base64.decode(padded, Base64.URL_SAFE | Base64.NO_WRAP);
    }

    private static String sha256Hex(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder();
            for (byte x : d) b.append(String.format(Locale.ROOT, "%02x", x));
            return b.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null || a.length() != b.length()) return false;
        int r = 0;
        for (int i = 0; i < a.length(); i++) r |= a.charAt(i) ^ b.charAt(i);
        return r == 0;
    }
}
