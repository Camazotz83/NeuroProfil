window.NP_CONFIG = {
  version: "5.1.0",
  edition: "Accessible Practice",
  audience: "Erwachsene ab 18 Jahren",
  paypal: "https://www.paypal.com/paypalme/wahmhoff83",
  privacyUrl: "",
  termsUrl: "",
  playProducts: {
    report: "neuroprofil_report_plus",
    yearly: "neuroprofil_pro_yearly",
    lifetime: "neuroprofil_pro_lifetime"
  },
  fallbackPrices: {
    report: "4,99 €",
    yearly: "19,99 € / Jahr",
    lifetime: "44,99 € einmalig"
  },
  imprint: {
    name: "[Name des Anbieters ergänzen]",
    address: "[ladungsfähige Anschrift ergänzen]",
    email: "[Support-/Kontakt-E-Mail ergänzen]"
  }
};
