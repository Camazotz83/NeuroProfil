# NeuroProfil 5.1 — Accessible Practice

NeuroProfil 5.1 is a privacy-first Android self-anamnesis and formulation workbook for adults.

## What changed from 5.0
- larger, calmer typography and stronger contrast defaults
- Android system font scaling is respected
- in-app text sizes: Standard / Groß / Sehr groß
- optional high-contrast and reduced-motion modes
- simplified four-item bottom navigation; overview via the NeuroProfil header
- more consistent German copy and terminology
- dedicated Access & License center
- Free remains usable without registration
- Google Play Billing remains the purchase route for digital Play features
- signed offline license keys are supported for explicitly issued licenses
- preview-owner shortcut: user `Sasa` + chosen key (preview/direct builds only)
- public Play builds do **not** contain that owner master password as a usable bypass
- dedicated Impressum/Privacy/Methodology access from the home screen
- version 5.1.0 / versionCode 8 / targetSdk 36

## Clinical/product boundary
NeuroProfil does not diagnose ADHD or autism, does not calculate diagnosis probability, and does not claim OPD-3 assessment. It structures self-report, functional impact, developmental context, competing explanations, resources, and formulation hypotheses.

## License security
Production license keys use ECDSA P-256 signatures. Only the public verification key is shipped in the app. Keep the private signing key outside the public repository.
