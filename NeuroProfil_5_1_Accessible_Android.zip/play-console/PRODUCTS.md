# NeuroProfil 5.1 – Monetarisierung

Empfohlene Startpreise für Deutschland:

- `neuroprofil_report_plus` — Bericht Plus — 4,99 € einmalig
- `neuroprofil_pro_yearly` — Pro — 19,99 € / Jahr
- `neuroprofil_pro_lifetime` — Pro dauerhaft — 44,99 € einmalig

Prinzipien:
- Kern-Selbstanamnese bleibt frei.
- Keine Diagnose, kein Risikoscore und keine Krisen-/Sicherheitsfunktion hinter einer Paywall.
- Bericht Plus verkauft Dokumentation/Export, nicht eine „genauere“ fachliche Aussage.
- Pro verkauft Verlauf, unbegrenzte Vertiefungen und Komfort.
- In Google Play werden digitale Käufe ausschließlich über Google Play Billing angeboten.
- Zugangsschlüssel werden in der App nicht verkauft und enthalten keinen externen Kauf-Link.
