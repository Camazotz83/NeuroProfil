# NeuroProfil 5.0 — Play-Release-Checkliste

1. Preview auf echtem Gerät und Android-16-Emulator testen.
2. Echte Anbieterangaben als GitHub Secrets hinterlegen: NEURO_LEGAL_NAME, NEURO_LEGAL_ADDRESS, NEURO_LEGAL_EMAIL.
3. GitHub Pages Workflow ausführen und Datenschutz/Impressum/Nutzungsbedingungen öffentlich prüfen.
4. Google Play App Signing aktivieren; bisherigen NeuroProfil Upload-Key weiterverwenden und privat sichern.
5. Drei Play-Produkte exakt anlegen:
   - neuroprofil_report_plus (Einmalkauf)
   - neuroprofil_pro_yearly (Abo)
   - neuroprofil_pro_lifetime (Einmalkauf)
6. Startpreise konfigurieren und lokalisierte Play-Preise kontrollieren.
7. Health Apps Declaration ausfüllen; Mental/Behavioral Health prüfen.
8. Data Safety anhand des finalen AAB ausfüllen.
9. Store Listing einschließlich Nicht-Medizinprodukt-/Nicht-Diagnose-Hinweis eintragen.
10. AAB über build-neuroprofil-5-play.yml bauen.
11. Zuerst Internal Testing; Käufe, Wiederherstellung, Kündigung, Offline-Start, PDF, Export/Import, Datenlöschung, große Schrift und Bildschirmrotation testen.
12. Danach Closed Testing, falls das Konto dies verlangt.
13. Erst nach realem Nutzerfeedback Production beantragen.
14. Preis- und Paywall-Texte auf Verständlichkeit und Dark-Pattern-Freiheit kontrollieren.
15. Vor jedem Update Health-/Payments-/Target-SDK-Richtlinien erneut prüfen.
