# Google Play Listing — NeuroProfil 5.0

## Titel
NeuroProfil – Selbstanamnese

## Kurzbeschreibung
Beobachtungen, Verlauf und Kontext strukturiert ordnen — privat, differenziert und ohne Scheindiagnosen.

## Vollständige Beschreibung
NeuroProfil ist ein ruhiges Arbeitsbuch für Erwachsene, die wiederkehrende Beobachtungen zu Aufmerksamkeit, Sensorik, sozialer Kommunikation, Regulation und Alltag verständlich sortieren möchten.

Statt aus Häkchen eine Diagnosewahrscheinlichkeit zu errechnen, betrachtet NeuroProfil Entwicklungsbeginn, mehrere Lebensbereiche, Funktionsbeeinträchtigung, Außenperspektive, Ressourcen, Alternativerklärungen und Gegenbelege.

Enthalten sind unter anderem:
- 136 alltagsnahe Beobachtungen
- Entwicklungs- und Kontextanamnese
- Funktionsprofile zu Exekutivfunktionen, Sensorik, Interozeption, Emotion und sozialer Verarbeitung
- 5-P-Fallformulierung: aktuell, Voraussetzungen, Auslöser, aufrechterhaltende und schützende Faktoren
- psychodynamische Reflexionsfragen zu Beziehungsschleifen, inneren Spannungsthemen und psychischen Funktionen — ohne OPD-Diagnostik
- Ressourcen und hilfreiche Anpassungen
- falsifikationsorientierte Auswertung
- Kurz- und Vollbericht
- lokaler Verlauf

Datenschutz: Keine Anmeldung, keine Werbung, keine Analytics, keine Cloud-Synchronisation. Inhaltliche Gesundheitsangaben bleiben lokal auf dem Gerät.

Wichtiger Hinweis: NeuroProfil ist kein Medizinprodukt, kein validierter Screening- oder Diagnosetest und dient nicht der Diagnose, Behandlung, Heilung oder Prävention von Krankheiten. Für medizinischen Rat, Diagnose oder Behandlung wende dich an eine qualifizierte Fachperson.
