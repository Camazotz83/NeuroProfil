# NeuroProfil 5.0 — Klinische Methodik und Grenzen

NeuroProfil ist eine strukturierte Selbstanamnese für Erwachsene, kein validierter Screening- oder Diagnosetest.

## Leitprinzipien

1. Beobachtung vor Etikett: konkrete, wiederkehrende Situationen werden vor diagnostischen Begriffen erfasst.
2. Verlauf vor Trefferzahl: früher Beginn, mehrere Lebensbereiche und Stabilität werden getrennt dokumentiert.
3. Funktion vor Eigenart: Leidensdruck, Alltag, Beziehungen, Arbeit/Studium und Kompensationsaufwand werden separat betrachtet.
4. Evidenz vor Gewissheit: Selbsterinnerung, Fremdbeobachtung und Dokumente werden als unterschiedliche Quellen sichtbar gemacht.
5. Falsifikation: Alternativerklärungen, Zustandsabhängigkeit, Kontextbegrenzung und Gegenbeispiele haben denselben Platz wie stützende Hinweise.
6. Ressourcen gehören in die Formulierung: hilfreiche Bedingungen, Stärken und Anpassungen werden nicht als Nebensatz behandelt.
7. Psychodynamische Reflexion bleibt Hypothese: Beziehungsschleifen, Spannungsthemen und psychische Funktionen sind an moderne psychodynamische Fallformulierung/OPD-3-Denkachsen angelehnt, aber es findet keine OPD-3-Diagnostik und kein OPD-Rating statt.
8. 5-P-Fallformulierung: Presenting, Predisposing, Precipitating, Perpetuating, Protective werden als verständliche Landkarte genutzt. Die Formulierung ist veränderbar und soll im Gespräch überprüft werden.

## Quellenrahmen

- NICE NG87 ADHD: umfassende klinische/psychosoziale und Entwicklungsanamnese, mehrere Settings, Funktionsbeeinträchtigung; keine Diagnose nur anhand einer Rating-Skala.
- NICE CG142 Autism in adults: Entwicklung, Funktionsniveau in mehreren Lebensbereichen, Fremd-/Dokumenteninformationen, Differentialdiagnosen, physische/psychische Begleiterkrankungen und Sensorik.
- OPD-3: Krankheitserleben/Behandlungsvoraussetzungen, Beziehung, Konflikt und Struktur als klinische psychodynamische Achsen; NeuroProfil übernimmt keine geschützten OPD-Items und simuliert kein OPD-Interview.
- NHS/HEE 5-P formulation: Formulierung als gemeinsame, vorläufige Hypothese, die mit neuen Informationen überarbeitet wird.

## Nicht behaupten

- keine ADHS-/Autismus-/AuDHD-Wahrscheinlichkeit
- keine klinische Validierung der 136 Beobachtungen
- keine Sensitivität/Spezifität oder Cut-offs
- keine OPD-3-Auswertung
- keine medizinische Diagnose oder Therapieempfehlung


## Accessibility / readability (5.1)
- Android system font scaling is respected up to 200%.
- In-app text scale provides Standard, Groß, Sehr groß.
- Touch targets are designed at 48 dp / approximately 48 CSS px or larger for principal controls.
- Text must reflow without horizontal reading scroll on phone layouts.
- Accent and muted text colors were contrast-checked against the app background.
- Meaning is not conveyed by color alone.
- Reduced-motion and high-contrast preferences are available.
