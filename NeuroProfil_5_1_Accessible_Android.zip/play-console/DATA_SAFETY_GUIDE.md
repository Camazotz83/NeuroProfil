# Google Play — Data Safety Ausgangslage

Technische Ausgangslage von NeuroProfil 5.0:
- Gesundheits-/Selbstanamnese-Inhalte werden lokal im App-Speicher verarbeitet.
- kein eigenes Konto
- keine Cloud-Synchronisation
- keine Werbung
- keine Analytics-/Tracking-SDKs
- keine Standort-, Kamera-, Mikrofon-, Kontakt- oder Health-Connect-Berechtigungen
- Android-Backups der App-Inhaltsdaten sind deaktiviert
- Export/Import wird vom Nutzer bewusst ausgelöst

Google Play Billing:
- Google Play verarbeitet die für den Kauf notwendigen Zahlungs-/Kontoinformationen.
- NeuroProfil erhält den Kaufstatus zur Freischaltung.
- Inhaltliche Antworten aus der Selbstanamnese werden nicht an Google Play gesendet.

Wichtig: Die Data-Safety-Angaben vor Einreichung anhand des tatsächlich erzeugten finalen AAB und aller dann eingebundenen SDKs erneut prüfen. Jede spätere Ergänzung von Crash Reporting, Analytics, Login oder Cloud-Sync verändert diese Erklärung.
