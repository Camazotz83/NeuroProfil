# Google Play — Health Apps Declaration für NeuroProfil 5.0

NeuroProfil bietet gesundheitsbezogene Inhalte zur psychischen Gesundheit / Verhaltensgesundheit und muss deshalb die Health Apps Declaration in der Play Console ausfüllen.

Voraussichtlich passend:
- Mental and Behavioral Health / psychische und verhaltensbezogene Gesundheit

Nicht als Medizinprodukt deklarieren, solange Funktionsumfang und Claims unverändert bleiben:
- keine Diagnose
- keine Therapie-/Behandlungsentscheidung
- keine klinische Entscheidungsunterstützung für Fachpersonal
- keine Messung physiologischer Parameter

In App und Store sichtbar lassen:
"NeuroProfil ist kein Medizinprodukt und kein validierter Screening- oder Diagnosetest. Die App strukturiert Selbstauskünfte und ersetzt keine qualifizierte medizinische, psychiatrische oder psychotherapeutische Untersuchung."

Vor Veröffentlichung die Health-Apps-Richtlinie in der Play Console erneut gegen den dann finalen Funktionsumfang prüfen.
