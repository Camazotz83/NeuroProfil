# NeuroProfil Android

Offline-first Android wrapper for the NeuroProfil self-observation app.

## Privacy
- No account, analytics, network API, advertising, or server storage.
- Checklist selections and clinical context are stored locally by Android WebView (DOM/local storage).
- PDF export uses Android's system print dialog; choose **Save as PDF** and then share the resulting file.
- The clinical section is a structured self-report, not a diagnosis or clinician-generated psychopathological examination.

## Build with GitHub Actions
1. Put this folder in a GitHub repository.
2. Open **Actions → Build NeuroProfil APK → Run workflow**.
3. Download artifact **NeuroProfil-Android-APK**.
4. Share `NeuroProfil-1.0.0.apk`. Recipients may need to allow installation from the app they opened the APK with.

## Local build
Requires Java 17+, Android SDK 35/build-tools 35.0.0 and Gradle 8.9:

```bash
gradle :app:assembleRelease
```

The release configuration currently uses the standard debug signing key so the sideloadable APK builds without private secrets. For long-term updates/distribution, replace this with a private release signing key and keep that key safely backed up.
