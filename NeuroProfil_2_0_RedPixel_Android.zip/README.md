# NeuroProfil 2.0 — Red Pixel Edition

Major visual redesign with Miauschka as the launcher/app icon.

## What changed
- Miauschka red-pixel launcher icon + in-app masthead mark
- deliberate graphite/ivory/crimson visual system
- three clear destinations: Merkmale / Kontext / Auswertung
- flatter editorial layout instead of stacked generic cards/gradients
- clearer search/filter hierarchy and larger mobile tap targets
- revised clinical context layout
- revised PDF cover and report styling
- Android versionName 2.0.0 / versionCode 4
- targetSdk 34, minSdk 23

## Build
Use `.github/workflows/build-neuroprofil-2.yml` or Android Studio.

Important: older NeuroProfil test releases were signed with temporary CI keys.
If Android reports an update/signature conflict, uninstall the old test build first.
